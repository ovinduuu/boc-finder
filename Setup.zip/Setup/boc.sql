-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2019 at 01:04 AM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boc`
--

-- --------------------------------------------------------

--
-- Table structure for table `cash`
--

CREATE TABLE IF NOT EXISTS `cash` (
  `date` varchar(10) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(10) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dbal`
--

CREATE TABLE IF NOT EXISTS `dbal` (
  `date` date NOT NULL,
  `ybal` float NOT NULL DEFAULT '0',
  `in` float NOT NULL DEFAULT '0',
  `out` float NOT NULL DEFAULT '0',
  `tbal` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `delitems`
--

CREATE TABLE IF NOT EXISTS `delitems` (
  `dnt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `item` text NOT NULL,
  `unq` varchar(50) NOT NULL,
  `reason` text NOT NULL,
  PRIMARY KEY (`dnt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `limitno` varchar(20) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  PRIMARY KEY (`limitno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` varchar(50) NOT NULL,
  `dnt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dnt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `dnt`) VALUES
('admin', '2019-09-09 03:52:09'),
('admin', '2019-09-09 05:05:34'),
('admin', '2019-09-09 05:14:50'),
('pf151580', '2019-09-09 05:17:20'),
('admin', '2019-09-09 05:28:50'),
('pf213463', '2019-09-09 07:49:46'),
('admin', '2019-09-09 08:10:38'),
('admin', '2019-09-09 08:13:53'),
('admin', '2019-09-09 09:09:46'),
('admin', '2019-09-09 10:27:17');

-- --------------------------------------------------------

--
-- Table structure for table `pbu`
--

CREATE TABLE IF NOT EXISTS `pbu` (
  `accno` int(11) NOT NULL,
  `cupno` int(10) NOT NULL,
  `rowno` int(10) NOT NULL,
  `fileno` int(10) NOT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ss`
--

CREATE TABLE IF NOT EXISTS `ss` (
  `fno` varchar(20) NOT NULL,
  `des` varchar(50) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  `cellno` int(11) NOT NULL,
  `units` int(11) NOT NULL DEFAULT '0',
  `cost` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`fno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stballog`
--

CREATE TABLE IF NOT EXISTS `stballog` (
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fno` varchar(20) NOT NULL,
  `type` text NOT NULL,
  `qty` int(11) NOT NULL,
  `bal` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tcash`
--

CREATE TABLE IF NOT EXISTS `tcash` (
  `date` varchar(10) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(10) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE IF NOT EXISTS `temp` (
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fno` varchar(20) NOT NULL,
  `type` text NOT NULL,
  `qty` int(11) NOT NULL,
  `uprice` float NOT NULL,
  `bal` float NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tloan`
--

CREATE TABLE IF NOT EXISTS `tloan` (
  `limitno` varchar(20) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  PRIMARY KEY (`limitno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tpbu`
--

CREATE TABLE IF NOT EXISTS `tpbu` (
  `accno` int(11) NOT NULL,
  `cupno` int(10) NOT NULL,
  `rowno` int(10) NOT NULL,
  `fileno` int(10) NOT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `umanagement`
--

CREATE TABLE IF NOT EXISTS `umanagement` (
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `category` text NOT NULL,
  `des` text NOT NULL,
  PRIMARY KEY (`datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `umanagement`
--

INSERT INTO `umanagement` (`datetime`, `id`, `type`, `category`, `des`) VALUES
('2019-09-09 05:15:53', 'pf151580', 'Staff Officer', 'Create User', 'New Officer'),
('2019-09-09 05:19:47', 'pf151580', 'Staff Officer', 'Update User', 'password reset'),
('2019-09-09 05:29:20', 'pf151580', 'Staff Officer', 'Create User', 'new member'),
('2019-09-09 05:32:51', 'pf151580', 'Staff Officer', 'Create User', '123212'),
('2019-09-09 05:36:26', 'pf151580', 'Staff Officer', 'Create User', 'new user'),
('2019-09-09 05:36:52', 'pf151580', 'Staff Officer', 'Delete User', 'trf to other branch'),
('2019-09-09 05:40:40', 'pf229808', 'Staff Assistant', 'Delete User', 'resign');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(50) NOT NULL,
  `name` text NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `type`) VALUES
('admin', 'admin', 'admin684', 'admin'),
('pf158338', 'Ishanka', 'kalum36', 'Staff Officer'),
('pf213463', 'Chalana', 'cha04', 'Chief Clerk');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
