-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2019 at 03:18 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boc`
--

-- --------------------------------------------------------

--
-- Table structure for table `cash`
--

CREATE TABLE IF NOT EXISTS `cash` (
  `date` varchar(10) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(10) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash`
--

INSERT INTO `cash` (`date`, `cupno`, `rowno`) VALUES
('15/07/2019', 5, 5),
('25/03/2019', 8, 6),
('28/02/2019', 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `dbal`
--

CREATE TABLE IF NOT EXISTS `dbal` (
  `date` date NOT NULL,
  `ybal` float NOT NULL DEFAULT '0',
  `in` float NOT NULL DEFAULT '0',
  `out` float NOT NULL DEFAULT '0',
  `tbal` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbal`
--

INSERT INTO `dbal` (`date`, `ybal`, `in`, `out`, `tbal`) VALUES
('2019-07-11', 500, 450, 50, 900),
('2019-07-14', 400, 0, 300, 100),
('2019-07-15', 100, 1000, 300, 800),
('2019-07-16', 800, 3025, 364, 3461),
('2019-07-19', 3461, 128, 64, 3525);

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `limitno` varchar(20) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  PRIMARY KEY (`limitno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`limitno`, `cupno`, `rowno`) VALUES
('198/2019', 6, 8),
('208/2019', 51, 41),
('225/2018', 5, 6),
('229/2017', 8, 6),
('229/2018', 6, 5),
('229/2019', 5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` varchar(50) NOT NULL,
  `dnt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dnt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `dnt`) VALUES
('pf213463', '2019-07-16 14:31:10'),
('admin', '2019-07-16 14:32:02'),
('admin', '2019-07-16 15:03:14'),
('pf213463', '2019-07-16 15:04:04'),
('admin', '2019-07-16 18:02:10'),
('admin', '2019-07-16 18:04:48'),
('pf213463', '2019-07-16 18:05:31'),
('pf213463', '2019-07-16 18:07:39'),
('pf213463', '2019-07-19 09:08:24'),
('pf213463', '2019-07-19 09:22:58'),
('pf213463', '2019-07-19 13:45:00'),
('admin', '2019-07-19 14:10:00'),
('admin', '2019-07-19 14:12:04'),
('admin', '2019-07-19 14:15:08'),
('pf229808', '2019-07-19 14:16:17'),
('pf158338', '2019-07-19 14:22:05'),
('pf213463', '2019-07-19 14:29:39'),
('pf213463', '2019-07-19 14:44:55'),
('pf158338', '2019-07-19 14:45:27'),
('pf213463', '2019-07-19 14:47:01'),
('pf158338', '2019-07-19 14:47:25'),
('pf158338', '2019-07-19 14:49:17'),
('admin', '2019-07-19 14:51:41');

-- --------------------------------------------------------

--
-- Table structure for table `pbu`
--

CREATE TABLE IF NOT EXISTS `pbu` (
  `accno` int(11) NOT NULL,
  `cupno` int(10) NOT NULL,
  `rowno` int(10) NOT NULL,
  `fileno` int(10) NOT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pbu`
--

INSERT INTO `pbu` (`accno`, `cupno`, `rowno`, `fileno`) VALUES
(552255, 5, 2, 5),
(558822, 5, 8, 2),
(1016478, 8, 8, 8);

-- --------------------------------------------------------

--
-- Table structure for table `ss`
--

CREATE TABLE IF NOT EXISTS `ss` (
  `fno` varchar(20) NOT NULL,
  `des` varchar(50) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  `cellno` int(11) NOT NULL,
  `units` int(11) NOT NULL DEFAULT '0',
  `cost` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`fno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ss`
--

INSERT INTO `ss` (`fno`, `des`, `cupno`, `rowno`, `cellno`, `units`, `cost`) VALUES
('44', '44', 4, 4, 4, 4, 16),
('55', '55', 5, 5, 5, 3, 15),
('77', '77', 7, 7, 7, 93, 49704),
('88', '88', 8, 8, 8, 8, 64);

-- --------------------------------------------------------

--
-- Table structure for table `stballog`
--

CREATE TABLE IF NOT EXISTS `stballog` (
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fno` varchar(20) NOT NULL,
  `type` text NOT NULL,
  `qty` int(11) NOT NULL,
  `bal` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stballog`
--

INSERT INTO `stballog` (`date`, `fno`, `type`, `qty`, `bal`) VALUES
('2019-07-19 13:13:10', '88', 'in', 8, 64),
('2019-07-19 13:13:19', '88', 'in', 8, 64),
('2019-07-19 13:20:12', '88', 'out', 8, 64),
('2019-07-19 14:27:37', '44', 'in', 4, 16),
('2019-07-19 14:27:58', '55', 'in', 5, 25),
('2019-07-19 14:28:10', '55', 'out', 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tcash`
--

CREATE TABLE IF NOT EXISTS `tcash` (
  `date` varchar(10) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(10) NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE IF NOT EXISTS `temp` (
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fno` varchar(20) NOT NULL,
  `type` text NOT NULL,
  `qty` int(11) NOT NULL,
  `uprice` float NOT NULL,
  `bal` float NOT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tloan`
--

CREATE TABLE IF NOT EXISTS `tloan` (
  `limitno` varchar(20) NOT NULL,
  `cupno` int(11) NOT NULL,
  `rowno` int(11) NOT NULL,
  PRIMARY KEY (`limitno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tpbu`
--

CREATE TABLE IF NOT EXISTS `tpbu` (
  `accno` int(11) NOT NULL,
  `cupno` int(10) NOT NULL,
  `rowno` int(10) NOT NULL,
  `fileno` int(10) NOT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(50) NOT NULL,
  `name` text NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `type`) VALUES
('admin', 'admin', 'admin684', 'admin'),
('pf158338', 'Ishanka', 'kalum36', 'Staff Officer'),
('pf213463', 'Chalana', 'cha01', 'Chief Clerk'),
('pf229808', 'Dilan', 'dil789', 'Staff Assistant');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
